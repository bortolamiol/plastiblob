--
-- For more information on config.lua see the Project Configuration Guide at:
-- https://docs.coronalabs.com/guide/basics/configSettings
--

application =
{
	content =
	{
		width = 720,
		height = 1280, 
		scale = "zoomEven",
		fps = 60,
	},
}
